using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class OcclusionTargetSetter : MonoBehaviour
{
    public GameObject OCManager;
    public GameObject OccluderSample;

	public Material Dynamic;
    public Material Static;

    float Random (Vector2 p ) 
	{
		return Mathf.Abs((Mathf.Sin( p.x * 12.9898f + p.y * 78.233f ) * 43758.5453f) % 1);
	}

	void Awake()
	{
        List<GameObject> spheres = new List<GameObject>();
        spheres.Add(OccluderSample);
		int i = 0;
		// for (int x = 0; x < 64; x++)
		// {
		// 	for (int y = 0; y < 64; y++)
		// 	{
		// 		GameObject sp = GameObject.CreatePrimitive(PrimitiveType.Sphere);
		// 		sp.transform.localScale = new Vector3(1.0f, 1.0f, 1.0f);
		// 		sp.transform.position = new Vector3(x * 2.0f, 0.0f, y * 2.0f);
		// 		sp.name = "sphere" + i.ToString();
		// 		sp.GetComponent<Renderer>().material.SetColor("_Color", new Color(0.5f, 0.5f, 0.5f, 1.0f));
		// 		i++;
        //         spheres.Add(sp);
		// 	}
		// }

		for (int x = 0; x < 64; x++)
		{
			for (int y = 0; y < 64; y++)
			{
				GameObject sp = GameObject.CreatePrimitive(PrimitiveType.Sphere);
				float randomScale = UnityEngine.Random.Range(0.9f, 1.5f);
				sp.transform.localScale = new Vector3(randomScale, randomScale, randomScale);
				float randomX = UnityEngine.Random.Range(-3.0f, 3.0f);
                float randomY = UnityEngine.Random.Range(-2.0f, 2.0f);
                float randomZ = UnityEngine.Random.Range(-3.0f, 3.0f);
				sp.transform.position = new Vector3(x * 2.0f + randomX, randomY, y * 2.0f + randomZ);
				sp.name = "sphere" + i.ToString();
				//sp.GetComponent<Renderer>().material.SetColor("_Color", new Color(0.5f, 0.5f, 0.5f, 1.0f));
				
				if(y%5==1)
					sp.GetComponent<Renderer>().material = Dynamic;
                else
					sp.GetComponent<Renderer>().material = Static;
                i++;
				spheres.Add(sp);
			}
		}
        OcclusionCullingManager OCMComponent = OCManager.GetComponent<OcclusionCullingManager>();
		OCMComponent.OCTargetObjects = spheres.ToArray();
		OCMComponent.enabled = false;
		OCMComponent.enabled = true;
    }




    // void Start()
	// {
	// 	List<GameObject> trees = new List<GameObject>();
	// 	Transform[] allChildren = GetComponentsInChildren<Transform>();
    //     foreach(Transform child in allChildren)
    //     {
    //         // if(child.GetComponent<MeshFilter>() == null)            
    //         //     continue;
    //         // Mesh mesh = child.GetComponent<MeshFilter>().mesh;
    //         // if(mesh != null)
          
    
    //         if(child.GetComponent<Renderer>() == null)            
    //             continue;
            
    //         trees.Add(child.gameObject);
    //     }
		
	// 	OCManager.GetComponent<OcclusionCullingManager>().OCTargets = trees.ToArray();
	// }
}
